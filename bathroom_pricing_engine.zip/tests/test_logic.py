from pricing_logic.material_db import get_material_cost
from pricing_logic.labor_calc import get_labor_details
from pricing_logic.vat_rules import get_vat_rate

def test_material_cost():
    cost, conf = get_material_cost("Lay ceramic floor tiles", 4, "Marseille")
    assert cost > 0 and conf >= 0.5

def test_labor_calc():
    hours, rate, conf = get_labor_details("Replace toilet", "Marseille", True)
    assert hours > 0 and rate > 0 and conf >= 0.5

def test_vat():
    assert get_vat_rate("Paint walls") == 10.0