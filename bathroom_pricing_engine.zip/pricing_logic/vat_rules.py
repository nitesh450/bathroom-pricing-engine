def get_vat_rate(task_name):
    if "paint" in task_name.lower():
        return 10.0
    elif "plumbing" in task_name.lower():
        return 20.0
    elif "tiles" in task_name.lower() or "ceramic" in task_name.lower():
        return 10.0
    else:
        return 10.0