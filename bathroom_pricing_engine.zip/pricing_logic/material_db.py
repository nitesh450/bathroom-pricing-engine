import json

def load_material_costs():
    with open("data/materials.json") as f:
        return json.load(f)

def get_material_cost(task_name, area, city):
    db = load_material_costs()
    city_factor = {"Marseille": 0.95, "Paris": 1.1}.get(city, 1.0)

    for entry in db:
        if entry["task"] in task_name.lower():
            unit_price = entry["unit_price"] * city_factor
            total_cost = unit_price * area if entry["unit"] == "sqm" else unit_price
            return total_cost, 0.9

    return 0.0, 0.5  # unknown material