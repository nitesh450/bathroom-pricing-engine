def get_labor_details(task_name, city, budget_sensitive):
    hourly_rates = {
        "Marseille": 40,
        "Paris": 55,
        "default": 50
    }
    base_durations = {
        "remove old tiles": 2,
        "redo plumbing": 3,
        "replace toilet": 1.5,
        "install vanity": 1.5,
        "paint walls": 2,
        "lay ceramic floor": 2.5
    }

    rate = hourly_rates.get(city, hourly_rates["default"])
    task_key = task_name.lower()

    for k, hours in base_durations.items():
        if k in task_key:
            if budget_sensitive:
                rate *= 0.9
            return hours, rate, 0.9

    return 2.0, rate, 0.5  # default duration and confidence